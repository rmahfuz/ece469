#ifndef __FILES_H__
#define __FILES_H__

#include "dfs.h"
#include "files_shared.h"

//#define FILE_MAX_OPEN_FILES 15



#endif
